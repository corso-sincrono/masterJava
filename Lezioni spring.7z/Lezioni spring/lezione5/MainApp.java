package org.corso.myexample.myInitDestroyExample;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/* Classe principale contenente il metodo main) */
public class MainApp {
	public static void main(String[] args) {
		/*
		 * Crea il contesto in base alle impostazioni dell'applicazione definite
		 * nel file Beans.xml
		 */
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(
				"Beans.xml");
		/*
		 * Recupera un bean avente id="helloWorld" nel file di configurazione
		 * Beans.xml
		 */
		HelloWorld obj = (HelloWorld) context.getBean("helloWorld");

		// Invoco il metodo che stampa il messaggio su tale oggetto
		obj.getMessage();

		/*
		 * Esegue lo shutdown dell'applicazione: registra un "gancio" all'evento
		 * di shutdown della JVM e prima che tale evento si verifichi esegue lo
		 * shudwon del contesto dell'applicazione distruggendo tutti i bean
		 * dell'applicazione e rilasciando lo spazio in memoria prima che si
		 * verifichi lo shudwon della JVM
		 */
		context.registerShutdownHook();
	}
}