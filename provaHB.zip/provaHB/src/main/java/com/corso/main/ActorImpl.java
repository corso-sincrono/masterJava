package com.corso.main;

import java.util.List;

import org.hibernate.Session;


public class ActorImpl {
	
	List<Actor> lista=null;
	Session session=null;
	
	public List<Actor> getAll(){
		
		session=DaoSession.getSessionFactory().openSession();
		session.beginTransaction();
		lista=session.createQuery( "from Actor" ).list();
		
		return lista;
		
	}

}
