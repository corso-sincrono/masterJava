package com.corso.main;

import java.util.List;

public class Test{

	public static void main(String[] args) {

		//ActorImpl im=new ActorImpl();
			List<Actor> l=ActorImpl.getAll();
			
			for(Actor a:l) {
				
			System.out.println("nome :"+a.getNome());
				
			}

	}

}
