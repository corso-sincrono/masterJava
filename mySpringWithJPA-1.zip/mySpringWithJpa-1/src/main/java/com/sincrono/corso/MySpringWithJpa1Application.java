package com.sincrono.corso;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@SpringBootApplication
public class MySpringWithJpa1Application {

	@Autowired
	ActorService as;
	
	@RequestMapping("/")
	public String getIndex(Model m) {
		
		List<Actor> a=as.findAll();
		m.addAttribute("att", a);
		
		return "index";
	}
	
	public static void main(String[] args) {
		
		SpringApplication.run(MySpringWithJpa1Application.class, args);
		
		
	
	}

}
