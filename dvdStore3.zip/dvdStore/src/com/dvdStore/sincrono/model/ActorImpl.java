package com.dvdStore.sincrono.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dvdStore.sincrono.dao.MyConnection;

public class ActorImpl implements ActorUtility {

	@Override
	public List<Actor> findByName(String n) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Actor> findAll() {
		
		Connection c=MyConnection.getConn();
		
		Actor at=null;
		
		List<Actor> list=new ArrayList<Actor>();
		
		try {
			
			
			Statement st=c.createStatement();
			
			ResultSet rst=st.executeQuery("select * from actor");
			
			
			
			while(rst.next()) {
				
				at=new Actor();
				
				at.setCognome(       rst.getString("last_name")      );
				at.setNome(       rst.getString("first_name")      );
				
				list.add(at);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		return list;
	}

}
