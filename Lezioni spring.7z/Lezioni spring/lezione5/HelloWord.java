package org.corso.myexample.myInitDestroyExample;

public class HelloWorld {

	private String message; // Messaggio da visualizzare

	/*
	 * Metodo usato per iniettare il valore della variabile message definito nel
	 * file Beans.xml
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	public void getMessage() {
		System.out.println("Your Message : " + message);
	}

	// Metodo di inizializzazione eseguito subito dopo la creazione del bean:
	public void init() {
		System.out.println("Bean is going through init.");
	}

	// Metodo destroy() eseguito subito prima della distruzione del bean:
	public void destroy() {
		System.out.println("Bean will destroy now.");
	}
}