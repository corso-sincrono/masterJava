package com.dvdStore.sincrono.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import com.dvdStore.sincrono.model.Actor;
import com.dvdStore.sincrono.model.ActorImpl;

public class MyConnection {
	
	
	private static Connection c=null;
	
	
	public static Connection getConn() {
		
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			c= DriverManager.getConnection("jdbc:mysql://localhost/sakila?user=root&&password=root");
			
			
			
		} 
		
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return c;
	}
	
	public static void main(String[] args) {
		MyConnection.getConn();
		
		
		ActorImpl x=new ActorImpl();
		
		List<Actor> l=x.findAll();
		
		for(int cont=0;cont<l.size();cont++) {
			
			
			
		System.out.println(l.get(cont).getCognome());
		
		}
		
	}
	

}
