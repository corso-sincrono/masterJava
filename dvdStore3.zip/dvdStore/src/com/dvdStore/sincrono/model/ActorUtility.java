package com.dvdStore.sincrono.model;

import java.util.List;

public interface ActorUtility {
	
	
	public List<Actor> findByName(String n);
	
	public List<Actor> findAll();

}
