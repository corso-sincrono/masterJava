package com.corso.main;

import java.util.List;

import org.hibernate.Session;


public class ActorImpl{

	static List<Actor> lista=null;
	static Session session=null;
	
	public static List<Actor> getAll(){
		
		session=DaoSession.getSessionFactory().openSession();
		session.beginTransaction();
		
		
		
		lista=session.createQuery( "from Actor" ).list();
		
		return lista;
		
	}

}
