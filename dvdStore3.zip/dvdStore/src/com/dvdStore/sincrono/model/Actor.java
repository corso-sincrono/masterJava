package com.dvdStore.sincrono.model;

public class Actor {
	
	
	private String nome;
	private String cognome;
	
	
	public Actor() {
		
		
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	
}
