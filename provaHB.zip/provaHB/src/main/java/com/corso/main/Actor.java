package com.corso.main;

public class Actor {
	
	private Integer actor_id;
	private String nome;
	private String cognome;
	
	
	public Actor(Integer actor_id, String nome, String cognome) {
		super();
		this.actor_id = actor_id;
		this.nome = nome;
		this.cognome = cognome;
	}


	public Actor() {
		super();
	}


	public Integer getActor_id() {
		return actor_id;
	}


	public void setActor_id(Integer actor_id) {
		this.actor_id = actor_id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	
	

}
