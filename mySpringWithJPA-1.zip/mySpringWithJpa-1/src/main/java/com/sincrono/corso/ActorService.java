package com.sincrono.corso;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ActorService extends JpaRepository<Actor, Integer> {

}
